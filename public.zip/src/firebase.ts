// src/firebase.js
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// TODO: Replace the following with your app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDDzAYsNamwryUdc547PE4AD1vdWIK7EwE",
  authDomain: "cardcade-42a5f.firebaseapp.com",
  projectId: "cardcade-42a5f",
  storageBucket: "cardcade-42a5f.firebasestorage.app",
  messagingSenderId: "108220685548",
  appId: "1:108220685548:web:1973fddea4432c5a1dd9c9",
};
//   measurementId: "G-R53MG6W8HV"

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize and export Firestore
const db = getFirestore(app);

// enablePersistence(db)
//   .catch((err: any) => {
//       if (err.code == 'failed-precondition') {
//           // Multiple tabs open, persistence can only be enabled in one tab at a time.
//           console.log("Persistence failed, probably multiple tabs open.");
//       } else if (err.code == 'unimplemented') {
//           // The current browser does not support all of the features required to enable persistence
//           console.log("Persistence is not available in this browser.");
//       }
//   });

export { db };